def _id(x):
    return x


_in_scalar = _id
_out_scalar = _id
_in_collection = _id
_out_collection = _id
