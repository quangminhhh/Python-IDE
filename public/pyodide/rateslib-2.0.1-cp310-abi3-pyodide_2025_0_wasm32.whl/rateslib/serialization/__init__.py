from __future__ import annotations

from rateslib.serialization.json import from_json

__all__ = ["from_json"]
