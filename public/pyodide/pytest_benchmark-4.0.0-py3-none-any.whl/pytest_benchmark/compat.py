import sys

PY38 = sys.version_info[0] == 3 and sys.version_info[1] >= 8
