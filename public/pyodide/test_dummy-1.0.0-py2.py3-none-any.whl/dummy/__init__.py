def dummy():
    return "dummy"
