from .css_inline import *

__doc__ = css_inline.__doc__
if hasattr(css_inline, "__all__"):
    __all__ = css_inline.__all__