Erik Welch                                      [@eriknw](https://github.com/eriknw/)

[Matthew Rocklin](http://matthewrocklin.com)    [@mrocklin](http://github.com/mrocklin/)

Lars Buitinck                                   [@larsmans](http://github.com/larsmans)

[Thouis (Ray) Jones](http://people.seas.harvard.edu/~thouis)  [@thouis](https://github.com/thouis/)

scoder                                          [@scoder](https://github.com/scoder/)

Phillip Cloud                                   [@cpcloud](https://github.com/cpcloud)

Joe Jevnik                                      [@llllllllll](https://github.com/llllllllll)
